CRC Trainer Devlopment.

This file is to explain the contents of this directory. It can also act as a interim communications pad between developers prior to the project passage into GIThub thingy.

If your security is set up for it, you should be able to double click on the jar and it should fire up the trainer. That can be used as a reference for functionality.

If you unpack the jar, drill down into the src folder and you will find the the .java files. The program is vaguely OO. It has a gui manager (crc_gui.java) that builds the interface and managers everything else.

The gui calls problem_data.java to get a new problem (data and pattern). Then calls each of the solvers to passing them the problem and the relavent part of the gui to fill in.

The problem generator uses the binary_number class to create and hold binary numbers. There is some commenting that tells you what the program is doing generally, but its minimal.

The html file is as far as I got translating the java OO into JS OO. I was looking to develop it as a Single Page Application.

Thanks for any assistance you can provide.

regards
Ian Baker